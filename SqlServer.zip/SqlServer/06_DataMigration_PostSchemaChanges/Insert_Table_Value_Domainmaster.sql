

INSERT INTO [dbo].[DMS_doQ_DOMAINMASTER]
           ([DOMAINMASTER_iID]
           ,[DOMAINMASTER_vName]
           ,[DOMAINMASTER_iOrgID]
           ,[DOMAINMASTER_bActive])
     VALUES
           (1,
		   'lotex.loc',
		   252,
		   1)
GO


